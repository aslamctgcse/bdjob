
<?php   
	$conn =mysqli_connect('localhost','root','','bdjob'); 
	$sql="select*from jobrequest";
	$result=mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="ISO-8859-1">
		<title>User Home</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>

<!-------------- navbar  -------------->

		<nav class="navbar navbar-default">
	    	<div class="container">
	        	<div class="navbar-header">          
	            <a class="navbar-brand" href="#">Bd Job</a>
	        	</div>

	        	<div class="collapse navbar-collapse">
	            <ul class="nav navbar-nav navbar-right">
	               <li class="active"><a href="#">Home</a></li>
	               <li><a href="#">Admin</a></li>
	               <li><a href="#">User</a></li>
	               <li><a href="#">Contact</a></li>
	           	</ul>             
	        	</div>
	    	</div>
		</nav>

		<div id="index" class="text-center">
			<h1>All Job Request</h1>
			<div class="row">
				<div class="col-sm-offset-4 col-sm-5">											
					<table class="table" border="5px solid blue">
						<thead align="center" style="background-color: #ddd;">
							<th>No</th>
							<th>Name</th>
							<th>Address</th>
							<th>Mobile</th>
							<th>Job Id</th>
							<th>Action</th>
						</thead>

					<?php while($row = mysqli_fetch_assoc($result)) { ?>
						<tbody>
							<tr>
								<td><label> <?= $row['id']; ?></label></td>
								<td><label> <?= $row['userName']; ?></label></td>
								<td><label> <?= $row['address']; ?></label></td>
								<td><label> <?= $row['mobile']; ?></label></td>
								<td><label> <?= $row['jobId']; ?></label></td>
								<td><button type="submit" class="btn btn-success">Accept</button></td>
							</tr>
						</tbody>
					<?php } ?> 
     				</table>  
     			</div>
     		</div>
     	</div>

		<div id="footer">
			<h2 class="text-center">Copyright @ Bd Job</h2>		
		</div>

	</body>
</html>