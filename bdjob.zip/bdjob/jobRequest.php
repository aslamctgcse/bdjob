
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="ISO-8859-1">
      <title>Admin Home</title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>

<!-------------- navbar  -------------->
      <nav class="navbar navbar-default">
         <div class="container">
            <div class="navbar-header">          
               <a class="navbar-brand" href="#">Bd Job</a>
            </div>

            <div class="collapse navbar-collapse">
               <ul class="nav navbar-nav navbar-right">
                  <li class="active"><a href="#">Home</a></li>
                  <li><a href="#">Admin</a></li>
                  <li><a href="#">User</a></li>
                  <li><a href="#">Contact</a></li>
               </ul>             
            </div>
         </div>
      </nav>

      <div id="index" class="text-center">
         <h1>Information for job request</h1>
         <div class="row" style="padding-top: 150px;">
            <form action="confirmRequest.php" method="POST" class="col-sm-offset-4 col-sm-4" style="border:3px solid blue;">  
               <h2>Enter Your Information</h2>
               <table class="table" border="5px solid blue">                  
                  <tr>
                     <th  class="text-right"><label>Your Name</label></th>
                     <td>
                        <input type="text" name="fullName" placeholder="Full Name" required>
                     </td>                 
                  </tr>
                  <tr>
                     <th  class="text-right"><label>Address</label></th>
                     <td>
                        <input type="text" name="address" placeholder="Address" required>
                     </td>                 
                  </tr>
                  <tr>
                     <th  class="text-right"><label>Mobile</label></th>
                     <td>
                        <input type="text" name="mobile" placeholder="Mobile" required>
                     </td>                 
                  </tr>  
                  <tr>
                     <th  class="text-right"><label>Choice job Id</label></th>
                     <td>
                        <input type="text" name="jobId" placeholder="Job Id" required>
                     </td>                 
                  </tr>                  
               </table>
               <button type="submit" class="btn btn-warning" name="">Apply now</button>  
            </form>           
         </div>
      </div>

      <div id="footer">
         <h2 class="text-center">Copyright @ Bd Job</h2>    
      </div>

   </body>
</html>