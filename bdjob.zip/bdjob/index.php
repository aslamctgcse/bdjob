
<?php   
	if(isset($_POST['submit'])){

	  	$area=$_POST['area'];  
   	$jobType=$_POST['jobType'];

	   $conn =mysqli_connect('localhost','root','',$area); 
	   $sql="select*from $jobType ";
	   $result=mysqli_query($conn,$sql);
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="ISO-8859-1">
		<title>User Home</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>

<!-------------- navbar  -------------->

		<nav class="navbar navbar-default">
	    	<div class="container">
	        	<div class="navbar-header">          
	            <a class="navbar-brand" href="#">Bd Job</a>
	        	</div>

	        	<div class="collapse navbar-collapse">
	            <ul class="nav navbar-nav navbar-right">
	               <li class="active"><a href="#">Home</a></li>
	               <li><a href="loginPage.php">Admin</a></li>
	               <li><a href="loginPage.php">User</a></li>
	               <li><a href="#">Contact</a></li>
	           	</ul>             
	        	</div>
	    	</div>
		</nav>

		<div id="index" class="text-center">
			<h1>Search Job</h1>			
			<div class="row">	
				<div class="col-sm-offset-4 col-sm-4" >					
					<form action="index.php" method="POST" style="border:3px solid blue;">				
						<table class="table" border="5px solid blue"  >
		     				<tr>   
		                  <th class="text-right"><label>Area</label></th>
		                     <td>
	                     		<select name='area' required>
						         		<option value="">Select area</option>
						         		<option value="dhaka">Dhaka</option>
						         		<option value="ctg">Chittagon</option>
						      		</select>
		                     </td>     
		               </tr>
		               <tr>   
		                  <th class="text-right"><label>Job Title</label></th>
		                     <td>
		                     	<select name='jobType' required>
								         <option value="">Select type</option>
								         <option value="cse">CSE</option>
								         <option value="eee">EEE</option>
								         <option value="other">Other</option>
								      </select>
		                     </td>     
		               </tr>
		            </table> 					
					<button type="submit" class="btn btn-success" name="submit">Action</button>  
				</form>				
			</div>
		</div>
		<br><br>	
	
			<?php if(isset($_POST['submit'])){ ?>				
				<?php while($row = mysqli_fetch_assoc($result)) { ?>
					<div class="row">					
						<div class="col-sm-offset-4 col-sm-4">
							<table class="table" border="5px solid blue">
								<h3 class="text-center"> <?= $area .' > '. $jobType .' > ' .'Job id:'. ' '. $row['id']; ?></h3>
		     					<tr>   
		                      <th  class="text-right"><label>Job Title</label></th>
		                     <td><label><?= $row['jobTitle']; ?></label></td>     
		                  </tr>
		                  <tr>
		                      <th  class="text-right"><label>Education</label></th>
		                     <td><label> <?= $row['education']; ?></label> </td>     
		                  </tr>
		                  <tr>		                 
		                      <th  class="text-right"><label>Salary</label></th>
		                     <td><label> <?= $row['salary']; ?> </label></td>     
		                  </tr>
		                  <tr>		   
		                      <th  class="text-right"><label>Experience</label></th>  
		                     <td><label> <?= $row['experience']. " year"; ?></label> </td>     
		                  </tr>
		                  <tr>
		                     <th  class="text-right"><label>Apply last date</label></th>
		                     <td><label>  <?= $row['applyDate']; ?> </label></td>     
		                  </tr>
		                  <tr>
		                     <th  class="text-right"><label>For User</label></th>
		                     <td>
		                     	<a href="jobRequest.php" class="btn btn-success ">Apply now</a>
		                    </td>     
		                  </tr>

     						</table>
     					</div>
     				</div>
     			<?php } } ?> 
     	</div>

		<div id="footer">
			<h2 class="text-center">Copyright @ Bd Job</h2>		
		</div>

	</body>
</html>