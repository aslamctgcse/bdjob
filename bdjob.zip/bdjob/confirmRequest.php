
<?php  

   $fullName=$_POST['fullName'];
   $address=$_POST['address'];
   $mobile=$_POST['mobile'];
   $jobId=$_POST['jobId'];

   $conn =mysqli_connect('localhost','root','','bdjob');  

   $sql="insert into jobrequest values ( null, '$fullName', '$address', '$mobile', '$jobId')";
   $result=mysqli_query($conn,$sql);


   if ($result) { 
      header("Location: index.php");
   }      
   else {
      echo "Sorry connection problrm, try again";
   }
?>




 
