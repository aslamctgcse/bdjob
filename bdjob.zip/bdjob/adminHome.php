<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="ISO-8859-1">
		<title>Admin Home</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>

<!-------------- navbar  -------------->

		<nav class="navbar navbar-default">
	    	<div class="container">
	        	<div class="navbar-header">          
	            <a class="navbar-brand" href="#">Bd Job</a>
	        	</div>

	        	<div class="collapse navbar-collapse">
	            <ul class="nav navbar-nav navbar-right">
	               <li class="active"><a href="#">Home</a></li>
	               <li><a href="loginPage.php">Admin</a></li>
	               <li><a href="loginPage.php">User</a></li>
	               <li><a href="#">Contact</a></li>
	           	</ul>             
	        	</div>
	    	</div>
		</nav>

		<div id="index" class="text-center">
			<h1>Admin Home page</h1>
			<div class="row">
				<form action="addJob.php" method="POST" class="col-sm-offset-2 col-sm-4">	
					<h2>Add job</h2>
					<table class="table" border="5px solid blue">
	               <tr>
	                  <th  class="text-right"><label>Area</label></th>
	                  <td>
	                     <select name='area' required>
							      <option value="">Select area</option>
							      <option value="dhaka">Dhaka</option>
							      <option value="ctg">Chittagon</option>			                		
					   		</select>
	                  </td>                 
	               </tr>
	               <tr>
	                  <th  class="text-right"><label>Job type</label></th>
	                  <td>
	                    <select name='jobType' required>
					         <option value="">Select type</option>
					         <option value="cse">CSE</option>
					         <option value="eee">EEE</option>
					         <option value="other">Other</option>
					      </select>		
	                  </td>                 
	               </tr>
	               <tr>
	                  <th  class="text-right"><label>Education</label></th>
	                  <td>
	                    	<select name='education' required>
							      <option value="">Select now</option>
							      <option value="psc">PSC</option>	 
							      <option value="jsc">JSC</option>	 
							      <option value="ssc">SSC</option>	 
							      <option value="BSC">BSC</option>	 
							      <option value="other">Other</option>	                		
							   </select>   
	                  </td>                 
	               </tr>
	               <tr>
	                  <th  class="text-right"><label>Job Title</label></th>
	                  <td>
	                    	<input type="text" name="jobTitle" placeholder="Enter Title" required>
	                  </td>                 
	               </tr>
	               <tr>
	                  <th  class="text-right"><label>Salary</label></th>
	                  <td>
	                    	<input type="text" name="salary" placeholder="Enter Salary" required>
	                  </td>                 
	               </tr>
	               <tr>
	                  <th  class="text-right"><label>Experience</label></th>
	                  <td>
	                    	<input type="text" name="experience" placeholder="Enter Experience" required>
	                  </td>                 
	               </tr>
	               <tr>
	                  <th  class="text-right"><label> Apply Last Date</label></th>
	                  <td>
	                    	<input type="date" name="applyDate" placeholder="date" required>
	                  </td>                 
	               </tr>
	            </table>
					<button type="submit" class="btn btn-warning" name="">Add Now</button>  
				</form>
				<div class="col-sm-4">
					<h2>Job Matter</h2>
					<div class="table" style="border: 2px solid #fff; padding: 90px 0px ;">
						<div>
							<a href="index.php" class="btn btn-filled btn-info ">See Post</a>
						</div>
						<div>
							<a href="allJobRequest.php" class="btn btn-filled btn-success ">Job Request</a>
						</div>
						<div>
							<a href="deletePost.php" class="btn btn-filled btn-danger">Delete post</a>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="footer">
			<h2 class="text-center">Copyright @ Bd Job</h2>		
		</div>

	</body>
</html>